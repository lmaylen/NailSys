
<?php
require 'config.php';

$titulo = 'NailSys | Belleza en cada detalle';

require 'includes/header.php';
?>

<section class="hero">
    <div class="container hero-grid">
        <div class="hero-copy">
            <span class="eyebrow">BEAUTY • CARE • CONFIDENCE</span>

            <h1>La belleza está en los <em>pequeños detalles.</em></h1>

            <p>
                Regálate un momento para ti. Descubre nuestros servicios
                de uñas, diseños especiales y tratamientos pensados
                para resaltar tu estilo.
            </p>

            <div class="hero-actions">
                <a class="btn" href="<?= usuario_actual() ? 'reservar.php' : 'registro.php' ?>">
                    Reserva tu cita →
                </a>

                <a class="text-link" href="servicios.php">
                    Descubrir servicios
                </a>
            </div>

            <div class="hero-note">
                <span class="stars">★★★★★</span>
                <span>Atención dedicada, resultados que enamoran.</span>
            </div>
        </div>

        <div class="hero-art">
            <div class="hero-image">
                <div class="hero-image-overlay">
                    <span>NAIL CARE</span>
                    <strong>Tu momento,<br>tu estilo.</strong>
                </div>
            </div>

            <div class="floating-card">
                <span class="floating-icon">✦</span>
                <div>
                    <strong>Un toque especial</strong>
                    <small>Para cada versión de ti</small>
                </div>
            </div>

            <span class="decor decor-one">✿</span>
            <span class="decor decor-two">✧</span>
        </div>
    </div>
</section>

<section class="trust-strip">
    <div class="container trust-grid">
        <div><strong>01</strong><span>Atención personalizada</span></div>
        <div><strong>02</strong><span>Diseños a tu gusto</span></div>
        <div><strong>03</strong><span>Reserva fácil y rápida</span></div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-heading">
            <div>
                <span class="eyebrow">CONOCE NAILSYS</span>
                <h2>Todo para resaltar<br>tu belleza</h2>
            </div>

            <p>
                Encuentra nuestros servicios, conoce las promociones
                disponibles y reserva tu próximo momento especial.
            </p>
        </div>

        <div class="service-grid">
            <article class="service-card">
                <div class="service-number">01 <span>✦</span></div>
                <span class="service-category">NUESTRO CATÁLOGO</span>
                <h3>Servicios</h3>
                <p>
                    Explora los tratamientos y servicios disponibles,
                    conoce sus precios y duración.
                </p>
                <div class="service-bottom">
                    <strong>Ver catálogo</strong>
                    <a class="round-link" href="servicios.php">↗</a>
                </div>
            </article>

            <article class="service-card">
                <div class="service-number">02 <span>✦</span></div>
                <span class="service-category">BENEFICIOS ESPECIALES</span>
                <h3>Promociones</h3>
                <p>
                    Descubre los descuentos y beneficios que tenemos
                    preparados para ti.
                </p>
                <div class="service-bottom">
                    <strong>Ver promociones</strong>
                    <a class="round-link" href="promociones.php">↗</a>
                </div>
            </article>

            <article class="service-card">
                <div class="service-number">03 <span>✦</span></div>
                <span class="service-category">AGENDA TU MOMENTO</span>
                <h3>Reserva tu cita</h3>
                <p>
                    Selecciona tu servicio, profesional y horario
                    para solicitar una cita.
                </p>
                <div class="service-bottom">
                    <strong>Reservar ahora</strong>
                    <a class="round-link" href="<?= usuario_actual() ? 'reservar.php' : 'registro.php' ?>">↗</a>
                </div>
            </article>
        </div>
    </div>
</section>

<section class="cta-section">
    <div class="container cta-box">
        <div>
            <span class="eyebrow">ES TU MOMENTO</span>
            <h2>¿Lista para renovar tu estilo?</h2>
            <p>Agenda tu próxima visita en unos cuantos pasos.</p>
        </div>

        <a class="btn btn-light" href="<?= usuario_actual() ? 'reservar.php' : 'registro.php' ?>">
            Agendar ahora →
        </a>
    </div>
</section>

<?php require 'includes/footer.php'; ?>
