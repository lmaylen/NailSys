
<?php
$usuario = usuario_actual();
$pagina = basename($_SERVER['PHP_SELF']);
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#FFFDF8">

    <title><?= e($titulo ?? 'NailSys | Belleza en cada detalle') ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/estilos.css">
</head>

<body>

<header class="site-header">
    <div class="container nav-wrap">

        <a class="brand" href="index.php">
            <span class="brand-mark">N</span>
            <span>
                Nail<span>Sys</span>
                <small>BEAUTY STUDIO</small>
            </span>
        </a>

        <button class="menu-toggle" type="button"
            aria-label="Abrir menú" aria-expanded="false">
            ☰
        </button>

        <nav class="main-nav">

            <a class="<?= $pagina === 'index.php' ? 'active' : '' ?>"
               href="index.php">Inicio</a>

            <a class="<?= $pagina === 'servicios.php' ? 'active' : '' ?>"
               href="servicios.php">Servicios</a>

            <a class="<?= $pagina === 'promociones.php' ? 'active' : '' ?>"
               href="promociones.php">Promociones</a>

            <?php if ($usuario): ?>

                <a href="mis-citas.php">Mis citas</a>

                <?php if (($usuario['rol'] ?? '') === 'Administrador'): ?>
                    <a href="admin.php">Administración</a>
                <?php endif; ?>

                <span class="nav-user">
                    Hola, <?= e($usuario['nombres']) ?>
                </span>

                <a class="btn btn-small btn-outline"
                   href="logout.php">Salir</a>

            <?php else: ?>

                <a href="login.php">Iniciar sesión</a>

                <a class="btn btn-small"
                   href="registro.php">Crear cuenta</a>

            <?php endif; ?>

        </nav>
    </div>
</header>

<main>

<?php if ($f = obtener_flash()): ?>
    <div class="container">
        <div class="alert alert-<?= e($f['tipo']) ?>">
            <?= e($f['mensaje']) ?>
        </div>
    </div>
<?php endif; ?>
