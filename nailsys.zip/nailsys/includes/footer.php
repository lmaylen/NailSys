
</main>

<footer class="site-footer">
    <div class="container footer-grid">

        <div>
            <a class="brand brand-footer" href="index.php">
                <span class="brand-mark">N</span>
                <span>
                    Nail<span>Sys</span>
                    <small>BEAUTY STUDIO</small>
                </span>
            </a>

            <p>Un espacio para consentirte y expresar tu estilo.</p>
        </div>

        <div>
            <strong>Explora</strong>
            <a href="index.php">Inicio</a>
            <a href="servicios.php">Servicios</a>
            <a href="promociones.php">Promociones</a>
            <a href="mis-citas.php">Mis citas</a>
        </div>

        <div>
            <strong>Contacto</strong>
            <span>Bogotá, Colombia</span>
            <span>300 123 4567</span>
            <span>contacto@nailsys.com</span>
        </div>

    </div>

    <div class="container copyright">
        © <?= date('Y') ?> NailSys. Todos los derechos reservados.
    </div>
</footer>

<script src="assets/app.js"></script>
</body>
</html>
