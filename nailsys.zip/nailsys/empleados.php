<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
exigir_login();

$mensaje = obtener_flash();
$editar = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validar_csrf();

    $accion = $_POST['accion'] ?? '';

    try {
        if ($accion === 'registrar') {
            $nombres = trim($_POST['nombres'] ?? '');
            $apellidos = trim($_POST['apellidos'] ?? '');
            $documento = trim($_POST['documento'] ?? '');
            $correo = trim($_POST['correo'] ?? '');
            $telefono = trim($_POST['telefono'] ?? '');
            $contrasena = $_POST['contrasena'] ?? '';
            $especialidad = trim($_POST['especialidad'] ?? '');
            $descripcion = trim($_POST['descripcion'] ?? '');
            $fecha = $_POST['fecha_contratacion'] ?: null;
            $salario = $_POST['salario'] !== '' ? (float)$_POST['salario'] : null;

            if (
                $nombres === '' || $apellidos === '' ||
                $correo === '' || $contrasena === '' ||
                !filter_var($correo, FILTER_VALIDATE_EMAIL)
            ) {
                throw new Exception('Completa los campos obligatorios y verifica el correo.');
            }

            if (strlen($contrasena) < 8) {
                throw new Exception('La contraseña debe tener mínimo 8 caracteres.');
            }

            $rol = $pdo->prepare(
                "SELECT id_rol FROM roles WHERE nombre = 'Empleado' LIMIT 1"
            );
            $rol->execute();
            $idRol = $rol->fetchColumn();

            if (!$idRol) {
                throw new Exception('No existe el rol Empleado en la base de datos.');
            }

            $pdo->beginTransaction();

            $sqlUsuario = $pdo->prepare(
                "INSERT INTO usuarios
                (id_rol, nombres, apellidos, numero_documento,
                 correo, telefono, contrasena, estado)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'Activo')"
            );

            $sqlUsuario->execute([
                $idRol,
                $nombres,
                $apellidos,
                $documento ?: null,
                $correo,
                $telefono ?: null,
                password_hash($contrasena, PASSWORD_DEFAULT)
            ]);

            $idUsuario = (int)$pdo->lastInsertId();

            $sqlEmpleado = $pdo->prepare(
                "INSERT INTO empleados
                (id_usuario, especialidad, descripcion,
                 fecha_contratacion, salario, estado)
                VALUES (?, ?, ?, ?, ?, 'Disponible')"
            );

            $sqlEmpleado->execute([
                $idUsuario,
                $especialidad ?: null,
                $descripcion ?: null,
                $fecha,
                $salario
            ]);

            $pdo->commit();

            flash('success', 'Empleado registrado correctamente.');
            header('Location: empleados.php');
            exit;
        }

        if ($accion === 'actualizar') {
            $id = (int)($_POST['id_empleado'] ?? 0);

            $nombres = trim($_POST['nombres'] ?? '');
            $apellidos = trim($_POST['apellidos'] ?? '');
            $documento = trim($_POST['documento'] ?? '');
            $correo = trim($_POST['correo'] ?? '');
            $telefono = trim($_POST['telefono'] ?? '');
            $especialidad = trim($_POST['especialidad'] ?? '');
            $descripcion = trim($_POST['descripcion'] ?? '');
            $fecha = $_POST['fecha_contratacion'] ?: null;
            $salario = $_POST['salario'] !== '' ? (float)$_POST['salario'] : null;

            if (
                $id <= 0 || $nombres === '' ||
                $apellidos === '' || !filter_var($correo, FILTER_VALIDATE_EMAIL)
            ) {
                throw new Exception('Verifica los datos del empleado.');
            }

            $consulta = $pdo->prepare(
                "SELECT id_usuario FROM empleados WHERE id_empleado = ?"
            );
            $consulta->execute([$id]);
            $idUsuario = $consulta->fetchColumn();

            if (!$idUsuario) {
                throw new Exception('El empleado no existe.');
            }

            $pdo->beginTransaction();

            $sqlUsuario = $pdo->prepare(
                "UPDATE usuarios
                 SET nombres = ?, apellidos = ?, numero_documento = ?,
                     correo = ?, telefono = ?
                 WHERE id_usuario = ?"
            );

            $sqlUsuario->execute([
                $nombres,
                $apellidos,
                $documento ?: null,
                $correo,
                $telefono ?: null,
                $idUsuario
            ]);

            $sqlEmpleado = $pdo->prepare(
                "UPDATE empleados
                 SET especialidad = ?, descripcion = ?,
                     fecha_contratacion = ?, salario = ?
                 WHERE id_empleado = ?"
            );

            $sqlEmpleado->execute([
                $especialidad ?: null,
                $descripcion ?: null,
                $fecha,
                $salario,
                $id
            ]);

            $pdo->commit();

            flash('success', 'Información actualizada correctamente.');
            header('Location: empleados.php');
            exit;
        }

        if ($accion === 'estado') {
            $id = (int)($_POST['id_empleado'] ?? 0);
            $estado = $_POST['estado'] ?? '';

            if (!in_array($estado, ['Disponible', 'Inactivo'], true)) {
                throw new Exception('Estado no válido.');
            }

            $consulta = $pdo->prepare(
                "SELECT id_usuario FROM empleados WHERE id_empleado = ?"
            );
            $consulta->execute([$id]);
            $idUsuario = $consulta->fetchColumn();

            if (!$idUsuario) {
                throw new Exception('Empleado no encontrado.');
            }

            $pdo->beginTransaction();

            $pdo->prepare(
                "UPDATE empleados SET estado = ? WHERE id_empleado = ?"
            )->execute([$estado, $id]);

            $estadoUsuario = $estado === 'Disponible' ? 'Activo' : 'Inactivo';

            $pdo->prepare(
                "UPDATE usuarios SET estado = ? WHERE id_usuario = ?"
            )->execute([$estadoUsuario, $idUsuario]);

            $pdo->commit();

            flash('success', 'Estado del empleado actualizado.');
            header('Location: empleados.php');
            exit;
        }

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        flash('error', $e instanceof PDOException
            ? 'No se pudo guardar. Verifica que el correo y documento no estén registrados.'
            : $e->getMessage()
        );

        header('Location: empleados.php');
        exit;
    }
}

if (isset($_GET['editar'])) {
    $consulta = $pdo->prepare(
        "SELECT e.*, u.nombres, u.apellidos, u.numero_documento,
                u.correo, u.telefono
         FROM empleados e
         INNER JOIN usuarios u ON e.id_usuario = u.id_usuario
         WHERE e.id_empleado = ?"
    );
    $consulta->execute([(int)$_GET['editar']]);
    $editar = $consulta->fetch();

    if (!$editar) {
        flash('error', 'No se encontró el empleado.');
        header('Location: empleados.php');
        exit;
    }
}

$busqueda = trim($_GET['buscar'] ?? '');

$sql = "SELECT e.*, u.nombres, u.apellidos, u.numero_documento,
               u.correo, u.telefono
        FROM empleados e
        INNER JOIN usuarios u ON e.id_usuario = u.id_usuario";

if ($busqueda !== '') {
    $sql .= " WHERE u.nombres LIKE :busqueda
              OR u.apellidos LIKE :busqueda
              OR u.correo LIKE :busqueda
              OR e.especialidad LIKE :busqueda";
}

$sql .= " ORDER BY e.id_empleado DESC";

$stmt = $pdo->prepare($sql);

if ($busqueda !== '') {
    $stmt->execute(['busqueda' => "%$busqueda%"]);
} else {
    $stmt->execute();
}

$empleados = $stmt->fetchAll();

$total = (int)$pdo->query(
    "SELECT COUNT(*) FROM empleados"
)->fetchColumn();

$disponibles = (int)$pdo->query(
    "SELECT COUNT(*) FROM empleados WHERE estado = 'Disponible'"
)->fetchColumn();

$inactivos = (int)$pdo->query(
    "SELECT COUNT(*) FROM empleados WHERE estado = 'Inactivo'"
)->fetchColumn();

function dinero($valor): string {
    return '$' . number_format((float)$valor, 0, ',', '.');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de empleados | NailSys</title>
    <link rel="stylesheet" href="assets/estilos.css">
    <style>
        .employee-heading {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:20px;
            flex-wrap:wrap;
            margin-bottom:25px;
        }
        .employee-heading h1 {
            font:600 42px 'Playfair Display',serif;
            margin:0;
        }
        .employee-heading p {
            color:var(--muted);
            font-size:13px;
        }
        .employee-layout {
            display:grid;
            grid-template-columns:340px 1fr;
            gap:25px;
            align-items:start;
        }
        .employee-panel {
            background:white;
            padding:25px;
            border:1px solid var(--line);
            border-radius:6px;
            box-shadow:var(--shadow);
        }
        .employee-panel h2 {
            font:600 23px 'Playfair Display',serif;
            margin:0 0 18px;
        }
        .employee-form {
            display:grid;
            gap:13px;
        }
        .employee-form label {
            display:grid;
            gap:6px;
            font-size:11px;
            font-weight:700;
        }
        .employee-form input,
        .employee-form textarea {
            width:100%;
            padding:11px;
            border:1px solid var(--line);
            border-radius:4px;
            font:inherit;
            font-size:12px;
        }
        .employee-form textarea {
            resize:vertical;
            min-height:75px;
        }
        .employee-table {
            min-width:850px;
        }
        .employee-table td {
            vertical-align:middle;
        }
        .employee-name {
            font-weight:700;
            color:var(--ink);
        }
        .employee-email {
            display:block;
            color:var(--muted);
            font-size:10px;
        }
        .employee-actions {
            display:flex;
            align-items:center;
            gap:10px;
            flex-wrap:wrap;
        }
        .employee-search {
            display:flex;
            gap:8px;
            margin-bottom:17px;
        }
        .employee-search input {
            flex:1;
            min-width:0;
            border:1px solid var(--line);
            padding:11px;
            border-radius:4px;
        }
        .employee-status {
            padding:5px 10px;
            border-radius:20px;
            font-size:10px;
            background:#eaf6ec;
            color:#28743b;
        }
        .employee-status.inactive {
            background:#fff0f0;
            color:#a43a3a;
        }
        .employee-section-title {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:15px;
            margin-bottom:18px;
        }
        .employee-section-title h2 {
            font:600 24px 'Playfair Display',serif;
            margin:0;
        }
        @media(max-width:950px) {
            .employee-layout {grid-template-columns:1fr}
        }
    </style>
</head>
<body>

<header class="site-header">
    <div class="container nav-wrap">
        <a href="index.php" class="brand">
            <span class="brand-mark">N</span>
            <span>Nail<span>Sys</span><small>BEAUTY MANAGEMENT</small></span>
        </a>

        <nav class="main-nav">
            <a href="index.php">Inicio</a>
            <a href="servicios.php">Servicios</a>
            <a href="reservar.php">Reservar</a>
            <a href="empleados.php" class="active">Empleados</a>
            <a href="logout.php">Cerrar sesión</a>
        </nav>
    </div>
</header>

<main class="page-section">
    <div class="container">

        <div class="employee-heading">
            <div>
                <span class="eyebrow">ADMINISTRACIÓN DEL NEGOCIO</span>
                <h1>Gestión de empleados</h1>
                <p>Administra el personal y organiza tu equipo de trabajo.</p>
            </div>
        </div>

        <?php if ($mensaje): ?>
            <div class="alert alert-<?= e($mensaje['tipo']) ?>">
                <?= e($mensaje['mensaje']) ?>
            </div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <small>Total de empleados</small>
                <strong><?= $total ?></strong>
            </div>
            <div class="stat-card">
                <small>Disponibles</small>
                <strong><?= $disponibles ?></strong>
            </div>
            <div class="stat-card">
                <small>Inactivos</small>
                <strong><?= $inactivos ?></strong>
            </div>
        </div>

        <div class="employee-layout">

            <section class="employee-panel">
                <h2><?= $editar ? 'Editar empleado' : 'Registrar empleado' ?></h2>

                <form method="POST" class="employee-form">
                    <?= csrf_field() ?>

                    <input type="hidden" name="accion"
                           value="<?= $editar ? 'actualizar' : 'registrar' ?>">

                    <?php if ($editar): ?>
                        <input type="hidden" name="id_empleado"
                               value="<?= (int)$editar['id_empleado'] ?>">
                    <?php endif; ?>

                    <label>
                        Nombres *
                        <input type="text" name="nombres" required
                               value="<?= e($editar['nombres'] ?? '') ?>">
                    </label>

                    <label>
                        Apellidos *
                        <input type="text" name="apellidos" required
                               value="<?= e($editar['apellidos'] ?? '') ?>">
                    </label>

                    <label>
                        Documento
                        <input type="text" name="documento"
                               value="<?= e($editar['numero_documento'] ?? '') ?>">
                    </label>

                    <label>
                        Correo electrónico *
                        <input type="email" name="correo" required
                               value="<?= e($editar['correo'] ?? '') ?>">
                    </label>

                    <label>
                        Teléfono
                        <input type="text" name="telefono"
                               value="<?= e($editar['telefono'] ?? '') ?>">
                    </label>

                    <?php if (!$editar): ?>
                        <label>
                            Contraseña de acceso *
                            <input type="password" name="contrasena"
                                   minlength="8" required>
                        </label>
                    <?php endif; ?>

                    <label>
                        Especialidad
                        <input type="text" name="especialidad"
                               placeholder="Ej. Manicure, uñas acrílicas"
                               value="<?= e($editar['especialidad'] ?? '') ?>">
                    </label>

                    <label>
                        Descripción
                        <textarea name="descripcion"
                                  placeholder="Describe sus habilidades..."><?= e($editar['descripcion'] ?? '') ?></textarea>
                    </label>

                    <label>
                        Fecha de contratación
                        <input type="date" name="fecha_contratacion"
                               value="<?= e($editar['fecha_contratacion'] ?? '') ?>">
                    </label>

                    <label>
                        Salario
                        <input type="number" name="salario" min="0" step="1000"
                               value="<?= e(isset($editar['salario']) ? (string)$editar['salario'] : '') ?>">
                    </label>

                    <button type="submit" class="btn btn-block">
                        <?= $editar ? 'Guardar cambios' : 'Registrar empleado' ?>
                    </button>

                    <?php if ($editar): ?>
                        <a href="empleados.php" class="btn btn-outline btn-block">
                            Cancelar edición
                        </a>
                    <?php endif; ?>
                </form>
            </section>

            <section>
                <div class="employee-section-title">
                    <h2>Personal registrado</h2>
                </div>

                <form method="GET" class="employee-search">
                    <input type="search" name="buscar"
                           placeholder="Buscar por nombre, correo o especialidad..."
                           value="<?= e($busqueda) ?>">
                    <button class="btn btn-small" type="submit">Buscar</button>
                    <?php if ($busqueda !== ''): ?>
                        <a href="empleados.php" class="btn btn-outline btn-small">Limpiar</a>
                    <?php endif; ?>
                </form>

                <div class="table-wrap">
                    <table class="employee-table">
                        <thead>
                            <tr>
                                <th>Empleado</th>
                                <th>Especialidad</th>
                                <th>Teléfono</th>
                                <th>Salario</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (!$empleados): ?>
                            <tr>
                                <td colspan="6">No se encontraron empleados.</td>
                            </tr>
                        <?php endif; ?>

                        <?php foreach ($empleados as $emp): ?>
                            <tr>
                                <td>
                                    <span class="employee-name">
                                        <?= e($emp['nombres'] . ' ' . $emp['apellidos']) ?>
                                    </span>
                                    <span class="employee-email">
                                        <?= e($emp['correo']) ?>
                                    </span>
                                </td>
                                <td><?= e($emp['especialidad'] ?? 'Sin especialidad') ?></td>
                                <td><?= e($emp['telefono'] ?? 'No registrado') ?></td>
                                <td><?= dinero($emp['salario']) ?></td>
                                <td>
                                    <span class="employee-status <?= $emp['estado'] === 'Inactivo' ? 'inactive' : '' ?>">
                                        <?= e($emp['estado']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="employee-actions">
                                        <a class="btn-link"
                                           href="empleados.php?editar=<?= (int)$emp['id_empleado'] ?>">
                                            Editar
                                        </a>

                                        <form method="POST">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="accion" value="estado">
                                            <input type="hidden" name="id_empleado"
                                                   value="<?= (int)$emp['id_empleado'] ?>">
                                            <input type="hidden" name="estado"
                                                   value="<?= $emp['estado'] === 'Inactivo' ? 'Disponible' : 'Inactivo' ?>">

                                            <button type="submit" class="btn-link">
                                                <?= $emp['estado'] === 'Inactivo' ? 'Activar' : 'Desactivar' ?>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </div>
    </div>
</main>

<footer class="site-footer">
    <div class="container">
        <p>© <?= date('Y') ?> NailSys. Gestión de belleza y estilo.</p>
    </div>
</footer>

</body>
</html>
