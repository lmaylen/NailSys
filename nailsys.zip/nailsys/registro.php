
<?php

require 'config.php';

if (usuario_actual()) {
    header('Location: index.php');
    exit;
}

$errores = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    validar_csrf();

    $nombres = trim($_POST['nombres'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $correo = strtolower(trim($_POST['correo'] ?? ''));
    $telefono = trim($_POST['telefono'] ?? '');
    $documento = trim($_POST['documento'] ?? '');
    $contrasena = $_POST['contrasena'] ?? '';

    if ($nombres == '' || $apellidos == '' || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $errores[] = 'Completa tus nombres, apellidos y un correo válido.';
    }

    if (strlen($contrasena) < 8) {
        $errores[] = 'La contraseña debe tener al menos 8 caracteres.';
    }

    if (empty($errores)) {

        try {

            $pdo->beginTransaction();

            $consulta = $pdo->query("SELECT id_rol FROM roles WHERE nombre = 'Cliente'");
            $rol = $consulta->fetchColumn();

            if (!$rol) {
                throw new RuntimeException('No existe el rol Cliente en la base de datos.');
            }

            $consulta = $pdo->prepare("
                INSERT INTO usuarios
                (id_rol, nombres, apellidos, tipo_documento, numero_documento, correo, telefono, contrasena)
                VALUES (?, ?, ?, 'CC', ?, ?, ?, ?)
            ");

            $consulta->execute([
                $rol,
                $nombres,
                $apellidos,
                $documento ?: null,
                $correo,
                $telefono,
                password_hash($contrasena, PASSWORD_DEFAULT)
            ]);

            $idUsuario = $pdo->lastInsertId();

            $consulta = $pdo->prepare("INSERT INTO clientes (id_usuario) VALUES (?)");
            $consulta->execute([$idUsuario]);

            $pdo->commit();

            session_regenerate_id(true);

            $_SESSION['usuario'] = [
                'id_usuario' => $idUsuario,
                'nombres' => $nombres,
                'apellidos' => $apellidos,
                'correo' => $correo,
                'rol' => 'Cliente'
            ];

            flash('success', 'Tu cuenta fue creada correctamente.');

            header('Location: reservar.php');
            exit;

        } catch (Throwable $error) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            if ($error instanceof PDOException) {
                $errores[] = 'Ese correo o documento ya está registrado.';
            } else {
                $errores[] = $error->getMessage();
            }
        }
    }
}

$titulo = 'Crear cuenta | NailSys';

require 'includes/header.php';

?>

<section class="form-section">

    <div class="form-card form-card-wide">

        <span class="eyebrow">BIENVENIDA A NAILSYS</span>

        <h1>Crea tu cuenta</h1>

        <p class="form-intro">
            Regístrate para reservar y administrar tus citas.
        </p>

        <?php foreach ($errores as $error): ?>

            <div class="alert alert-error">
                <?= e($error) ?>
            </div>

        <?php endforeach; ?>

        <form method="POST" class="form-grid">

            <?= csrf_field() ?>

            <label>
                Nombres

                <input
                    type="text"
                    name="nombres"
                    maxlength="100"
                    value="<?= e($_POST['nombres'] ?? '') ?>"
                    required
                >
            </label>

            <label>
                Apellidos

                <input
                    type="text"
                    name="apellidos"
                    maxlength="100"
                    value="<?= e($_POST['apellidos'] ?? '') ?>"
                    required
                >
            </label>

            <label>
                Correo electrónico

                <input
                    type="email"
                    name="correo"
                    maxlength="120"
                    value="<?= e($_POST['correo'] ?? '') ?>"
                    required
                >
            </label>

            <label>
                Teléfono

                <input
                    type="text"
                    name="telefono"
                    maxlength="20"
                    value="<?= e($_POST['telefono'] ?? '') ?>"
                >
            </label>

            <label class="full">
                Número de documento

                <input
                    type="text"
                    name="documento"
                    maxlength="30"
                    value="<?= e($_POST['documento'] ?? '') ?>"
                >
            </label>

            <label class="full">
                Contraseña

                <input
                    type="password"
                    name="contrasena"
                    minlength="8"
                    required
                    autocomplete="new-password"
                >

                <small>Mínimo 8 caracteres.</small>
            </label>

            <div class="full">

                <button class="btn btn-block" type="submit">
                    Crear mi cuenta <span>→</span>
                </button>

            </div>

        </form>

        <p class="form-bottom">
            ¿Ya tienes una cuenta?
            <a href="login.php">Inicia sesión</a>
        </p>

    </div>

</section>

<?php require 'includes/footer.php'; ?>
