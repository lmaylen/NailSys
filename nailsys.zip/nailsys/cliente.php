
<?php
session_start();
require_once 'conexion.php';

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

$id_usuario = $_SESSION["id_usuario"];

$consulta = $conexion->prepare(
    "SELECT u.nombres, u.apellidos, r.nombre AS rol
     FROM usuarios u
     INNER JOIN roles r ON u.id_rol = r.id_rol
     WHERE u.id_usuario = ?
     LIMIT 1"
);

$consulta->bind_param("i", $id_usuario);
$consulta->execute();

$resultado = $consulta->get_result();
$usuario = $resultado->fetch_assoc();

if (!$usuario || strtolower($usuario["rol"]) !== "cliente") {
    header("Location: index.php");
    exit;
}

$nombre = htmlspecialchars($usuario["nombres"]);
$apellido = htmlspecialchars($usuario["apellidos"]);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi cuenta | NailSys</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<header class="encabezado">
    <div class="logo">NailSys<span>.</span></div>

    <nav>
        <a href="index.php">Inicio</a>
        <a href="servicios.php">Servicios</a>
        <a href="mis_citas.php">Mis citas</a>
    </nav>

    <a href="cerrar_sesion.php" class="boton">Cerrar sesión</a>
</header>

<main class="panel-cliente">

    <section class="bienvenida-cliente">
        <p class="subtitulo">TU ESPACIO PERSONAL</p>

        <h1>¡Hola, <?php echo $nombre; ?>! 💗</h1>

        <p>
            GUSTO EN ATENDERTE 
        </p>

        <a href="agendar.php" class="boton">
            Agendar una cita
        </a>
    </section>

    <section class="opciones-cliente">
         
        <div class="contenedor-servicios">

            <article class="tarjeta">
                
                <h3>Ver servicios</h3>
                <p>DESCRUBRE TODO LO QUE TENEMOS EN SERVICIOS PARA TU BELLLEZA</p>
                <a href="servicios.php">Explorar servicios →</a>
            </article>

            <article class="tarjeta">
                <div class="icono">📅</div>
                <h3>Agendar cita</h3>
                <p>RESERVA EN EL HORARIO QUE MEJOR SE ADAPTE PARA TI</p>
                <a href="agendar.php">Reservar ahora →</a>
            </article>

            <article class="tarjeta">
                <div class="icono">📝</div>
                <h3>Mis citas</h3>
                <p>Consulta tus reservas y revisa su estado.</p>
                <a href="mis_citas.php">Consultar citas →</a>
            </article>

        </div>
    </section>

</main>

<footer>
    <h2>NailSys<span>.</span></h2>
    <p>Tu belleza, nuestro compromiso.</p>
    <p>© 2026 NailSys. Todos los derechos reservados.</p>
</footer>

</body>
</html>
