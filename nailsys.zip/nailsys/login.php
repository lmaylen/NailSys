
<?php

require 'config.php';

if (usuario_actual()) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    validar_csrf();

    $correo = strtolower(trim($_POST['correo'] ?? ''));
    $contrasena = $_POST['contrasena'] ?? '';

    $consulta = $pdo->prepare("
        SELECT 
            u.id_usuario,
            u.nombres,
            u.apellidos,
            u.correo,
            u.contrasena,
            r.nombre AS rol
        FROM usuarios u
        INNER JOIN roles r ON r.id_rol = u.id_rol
        WHERE u.correo = ? AND u.estado = 'Activo'
        LIMIT 1
    ");

    $consulta->execute([$correo]);

    $usuario = $consulta->fetch();

    if ($usuario && password_verify($contrasena, $usuario['contrasena'])) {

        session_regenerate_id(true);

        unset($usuario['contrasena']);

        $_SESSION['usuario'] = $usuario;

        flash('success', '¡Qué gusto tenerte de vuelta!');

        header('Location: index.php');
        exit;

    } else {

        $error = 'Correo o contraseña incorrectos. Verifica tus datos e intenta nuevamente.';

    }
}

$titulo = 'Iniciar sesión | NailSys';

require 'includes/header.php';

?>

<section class="form-section">

    <div class="form-card">

        <span class="eyebrow">NOS ALEGRA VERTE</span>

        <h1>Inicia sesión</h1>

        <p class="form-intro">
            Ingresa a tu espacio NailSys.
        </p>

        <?php if ($error != ''): ?>

            <div class="alert alert-error">
                <?= e($error) ?>
            </div>

        <?php endif; ?>

        <form method="POST" class="form-stack">

            <?= csrf_field() ?>

            <label>
                Correo electrónico

                <input
                    type="email"
                    name="correo"
                    required
                    autocomplete="username"
                    value="<?= e($_POST['correo'] ?? '') ?>"
                >
            </label>

            <label>
                Contraseña

                <input
                    type="password"
                    name="contrasena"
                    required
                    autocomplete="current-password"
                >
            </label>

            <button class="btn btn-block" type="submit">
                Ingresar <span>→</span>
            </button>

        </form>

        <p class="form-bottom">
            ¿Todavía no tienes cuenta?
            <a href="registro.php">Regístrate aquí</a>
        </p>

    </div>

</section>

<?php require 'includes/footer.php'; ?>
