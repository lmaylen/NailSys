
<?php
require 'config.php';

$titulo = 'Promociones | NailSys';

$promos = $pdo->query("
    SELECT *
    FROM promociones
    WHERE estado = 'Activa'
    AND CURDATE() BETWEEN fecha_inicio AND fecha_fin
    ORDER BY descuento DESC
")->fetchAll();

require 'includes/header.php';
?>

<section class="page-section">
    <div class="container">
        <div class="section-heading">
            <div>
                <span class="eyebrow">BENEFICIOS ESPECIALES</span>
                <h1>Nuestras promociones</h1>
            </div>

            <p>
                Aprovecha nuestros descuentos y disfruta
                de tus servicios favoritos.
            </p>
        </div>

        <?php if (!$promos): ?>

            <div class="empty-state">
                <span>✦</span>
                <h2>Muy pronto tendremos promociones</h2>
                <p>Estamos preparando beneficios especiales para ti.</p>
            </div>

        <?php else: ?>

            <div class="promo-list">
                <?php foreach ($promos as $p): ?>
                    <article class="promo-card">
                        <span class="discount">
                            <?= (int)$p['descuento'] ?>%
                            <small>OFF</small>
                        </span>

                        <div>
                            <h3><?= e($p['nombre']) ?></h3>

                            <p><?= e($p['descripcion']) ?></p>

                            <small>
                                Válida hasta
                                <?= date('d/m/Y', strtotime($p['fecha_fin'])) ?>
                            </small>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>

        <?php endif; ?>

        <div style="margin-top:35px;">
            <a class="btn" href="servicios.php">
                Explorar servicios →
            </a>
        </div>
    </div>
</section>

<?php require 'includes/footer.php'; ?>
