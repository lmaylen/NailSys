
<?php

require 'config.php';

exigir_login();

$usuario = usuario_actual();

$consulta = $pdo->prepare("
    SELECT 
        c.*,
        GROUP_CONCAT(s.nombre SEPARATOR ', ') AS servicios,
        CONCAT(ue.nombres, ' ', ue.apellidos) AS profesional,
        GROUP_CONCAT(DISTINCT p.estado) AS pago_estado
    FROM clientes cl
    INNER JOIN citas c ON c.id_cliente = cl.id_cliente
    INNER JOIN empleados em ON em.id_empleado = c.id_empleado
    INNER JOIN usuarios ue ON ue.id_usuario = em.id_usuario
    LEFT JOIN detalle_citas dc ON dc.id_cita = c.id_cita
    LEFT JOIN servicios s ON s.id_servicio = dc.id_servicio
    LEFT JOIN pagos p ON p.id_cita = c.id_cita
    WHERE cl.id_usuario = ?
    GROUP BY c.id_cita
    ORDER BY c.fecha DESC, c.hora_inicio DESC
");

$consulta->execute([$usuario['id_usuario']]);

$citas = $consulta->fetchAll();

$titulo = 'Mis citas | NailSys';

require 'includes/header.php';

?>

<section class="page-section">

    <div class="container">

        <div class="section-heading">

            <div>
                <span class="eyebrow">TU ESPACIO PERSONAL</span>
                <h1>Mis citas</h1>
            </div>

            <a class="btn" href="reservar.php">
                Nueva reserva +
            </a>

        </div>

        <?php if (empty($citas)): ?>

            <div class="empty-state">

                <span>✿</span>

                <h2>Aún no tienes citas</h2>

                <p>
                    Cuando reserves un servicio, aparecerá aquí.
                </p>

                <a class="btn" href="reservar.php">
                    Reservar mi primera cita
                </a>

            </div>

        <?php else: ?>

            <div class="appointment-list">

                <?php foreach ($citas as $cita): ?>

                    <article class="appointment-card">

                        <div class="appointment-date">

                            <strong>
                                <?= date('d', strtotime($cita['fecha'])) ?>
                            </strong>

                            <span>
                                <?= strtoupper(date('M', strtotime($cita['fecha']))) ?>
                            </span>

                        </div>

                        <div class="appointment-info">

                            <h3>
                                <?= e($cita['servicios'] ?: 'Servicio') ?>
                            </h3>

                            <p>
                                Con <?= e($cita['profesional']) ?>
                                ·
                                <?= date('H:i', strtotime($cita['hora_inicio'])) ?>
                                a
                                <?= date('H:i', strtotime($cita['hora_fin'])) ?>
                            </p>

                            <small>
                                Pago: <?= e($cita['pago_estado'] ?: 'Pendiente') ?>
                            </small>

                        </div>

                        <div class="appointment-actions">

                            <span class="status status-<?= strtolower(str_replace(' ', '-', $cita['estado'])) ?>">
                                <?= e($cita['estado']) ?>
                            </span>

                            <?php if (
                                !in_array($cita['estado'], ['Cancelada', 'Completada', 'No asistio'], true)
                                && $cita['fecha'] >= date('Y-m-d')
                            ): ?>

                                <form
                                    method="POST"
                                    action="cancelar.php"
                                    onsubmit="return confirm('¿Seguro que deseas cancelar esta cita?');"
                                >

                                    <?= csrf_field() ?>

                                    <input
                                        type="hidden"
                                        name="id_cita"
                                        value="<?= (int)$cita['id_cita'] ?>"
                                    >

                                    <button class="btn-link danger" type="submit">
                                        Cancelar cita
                                    </button>

                                </form>

                            <?php endif; ?>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </div>

</section>

<?php require 'includes/footer.php'; ?>
