
<?php

require 'config.php';

exigir_login();

validar_csrf();

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header('Location: mis-citas.php');
    exit;
}

$idCita = (int)($_POST['id_cita'] ?? 0);

$usuario = usuario_actual();

$consulta = $pdo->prepare("
    UPDATE citas c
    INNER JOIN clientes cl ON cl.id_cliente = c.id_cliente
    SET 
        c.estado = 'Cancelada',
        c.motivo_cancelacion = 'Cancelada por el cliente'
    WHERE c.id_cita = ?
    AND cl.id_usuario = ?
    AND c.estado IN ('Pendiente', 'Confirmada')
    AND c.fecha >= CURDATE()
");

$consulta->execute([
    $idCita,
    $usuario['id_usuario']
]);

if ($consulta->rowCount() > 0) {

    flash('success', 'La cita fue cancelada.');

} else {

    flash('error', 'No fue posible cancelar esa cita.');

}

header('Location: mis-citas.php');
exit;

?>
