
<?php

require 'config.php';

exigir_login();

$usuario = usuario_actual();

$consulta = $pdo->prepare("SELECT id_cliente FROM clientes WHERE id_usuario = ?");
$consulta->execute([$usuario['id_usuario']]);
$idCliente = $consulta->fetchColumn();

if (!$idCliente) {
    flash('error', 'No se encontró tu perfil de cliente.');
    header('Location: index.php');
    exit;
}

$consulta = $pdo->query("SELECT * FROM servicios WHERE estado = 'Activo' ORDER BY nombre");
$servicios = $consulta->fetchAll();

$consulta = $pdo->query("SELECT * FROM metodos_pago WHERE estado = 'Activo' ORDER BY nombre");
$metodos = $consulta->fetchAll();

$consulta = $pdo->query("
    SELECT e.id_empleado, u.nombres, u.apellidos, e.especialidad
    FROM empleados e
    INNER JOIN usuarios u ON e.id_usuario = u.id_usuario
    WHERE e.estado = 'Disponible' AND u.estado = 'Activo'
    ORDER BY u.nombres
");

$empleados = $consulta->fetchAll();

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    validar_csrf();

    $servicio = $_POST['servicio'] ?? '';
    $empleado = $_POST['empleado'] ?? '';
    $fecha = $_POST['fecha'] ?? '';
    $hora = $_POST['hora'] ?? '';
    $modalidad = $_POST['modalidad'] ?? '';
    $metodo = $_POST['metodo'] ?? '';
    $observaciones = trim($_POST['observaciones'] ?? '');

    try {

        $consulta = $pdo->prepare("SELECT * FROM servicios WHERE id_servicio = ? AND estado = 'Activo'");
        $consulta->execute([$servicio]);
        $datosServicio = $consulta->fetch();

        $consulta = $pdo->prepare("
            SELECT 1 FROM empleado_servicio
            INNER JOIN empleados ON empleado_servicio.id_empleado = empleados.id_empleado
            WHERE empleado_servicio.id_empleado = ?
            AND empleado_servicio.id_servicio = ?
            AND empleados.estado = 'Disponible'
        ");

        $consulta->execute([$empleado, $servicio]);

        if (!$datosServicio || !$consulta->fetchColumn()) {
            throw new Exception('Selecciona un servicio y un profesional válido.');
        }

        $fechaValida = DateTime::createFromFormat('Y-m-d', $fecha);

        if (!$fechaValida || $fechaValida->format('Y-m-d') != $fecha || $fecha < date('Y-m-d')) {
            throw new Exception('Selecciona una fecha válida.');
        }

        if (!preg_match('/^(0[8-9]|1[0-7]):(00|30)$/', $hora)) {
            throw new Exception('Selecciona una hora entre las 08:00 y las 17:30.');
        }

        if (!in_array($modalidad, ['En linea', 'En establecimiento'])) {
            throw new Exception('Selecciona una modalidad de pago válida.');
        }

        $consulta = $pdo->prepare("SELECT id_metodo FROM metodos_pago WHERE id_metodo = ? AND estado = 'Activo'");
        $consulta->execute([$metodo]);

        if (!$consulta->fetchColumn()) {
            throw new Exception('Selecciona un método de pago.');
        }

        $horaInicio = new DateTime("$fecha $hora");
        $horaFin = clone $horaInicio;
        $horaFin->modify('+' . $datosServicio['duracion'] . ' minutes');

        $fin = $horaFin->format('H:i:s');

        if ($fin > '18:00:00') {
            throw new Exception('El servicio termina después del horario de atención.');
        }

        $pdo->beginTransaction();

        $consulta = $pdo->prepare("
            SELECT COUNT(*) FROM citas
            WHERE id_empleado = ?
            AND fecha = ?
            AND estado NOT IN ('Cancelada', 'No asistio')
            AND ? < hora_fin
            AND ? > hora_inicio
        ");

        $consulta->execute([$empleado, $fecha, $hora . ':00', $fin]);

        if ($consulta->fetchColumn() > 0) {
            throw new Exception('El profesional ya tiene una cita en ese horario.');
        }

        $consulta = $pdo->prepare("
            SELECT COUNT(*) FROM excepciones_horario
            WHERE id_empleado = ?
            AND fecha = ?
            AND (hora_inicio IS NULL OR (? < hora_fin AND ? > hora_inicio))
        ");

        $consulta->execute([$empleado, $fecha, $hora . ':00', $fin]);

        if ($consulta->fetchColumn() > 0) {
            throw new Exception('El profesional no está disponible en ese horario.');
        }

        $consulta = $pdo->prepare("
            INSERT INTO citas
            (id_cliente, id_empleado, fecha, hora_inicio, hora_fin, estado, observaciones)
            VALUES (?, ?, ?, ?, ?, 'Pendiente', ?)
        ");

        $consulta->execute([
            $idCliente,
            $empleado,
            $fecha,
            $hora . ':00',
            $fin,
            $observaciones
        ]);

        $idCita = $pdo->lastInsertId();

        $consulta = $pdo->prepare("
            INSERT INTO detalle_citas
            (id_cita, id_servicio, cantidad, precio_unitario, duracion_minutos)
            VALUES (?, ?, 1, ?, ?)
        ");

        $consulta->execute([
            $idCita,
            $servicio,
            $datosServicio['precio'],
            $datosServicio['duracion']
        ]);

        $consulta = $pdo->prepare("
            INSERT INTO pagos
            (id_cita, id_metodo, modalidad, monto, estado, observaciones)
            VALUES (?, ?, ?, ?, 'Pendiente', ?)
        ");

        $consulta->execute([
            $idCita,
            $metodo,
            $modalidad,
            $datosServicio['precio'],
            'Pago pendiente de confirmación'
        ]);

        $pdo->commit();

        flash('success', 'Tu solicitud de cita fue registrada correctamente.');

        header('Location: mis-citas.php');
        exit;

    } catch (Throwable $errorConsulta) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $error = $errorConsulta->getMessage();
    }
}

$titulo = 'Reservar una cita | NailSys';

require 'includes/header.php';

?>

<section class="form-section">

    <div class="form-card form-card-wide">

        <span class="eyebrow">RESERVA TU MOMENTO</span>

        <h1>Agenda tu cita</h1>

        <p class="form-intro">
            Selecciona tu servicio y el horario que mejor te funcione.
        </p>

        <?php if ($error != ''): ?>
            <div class="alert alert-error">
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="form-grid" id="booking-form">

            <?= csrf_field() ?>

            <label class="full">
                Servicio

                <select name="servicio" id="servicio" required>

                    <option value="">Selecciona un servicio</option>

                    <?php foreach ($servicios as $s): ?>

                        <option
                            value="<?= $s['id_servicio'] ?>"
                            data-price="<?= $s['precio'] ?>"
                            data-duration="<?= $s['duracion'] ?>"
                            <?= (int)($_POST['servicio'] ?? $_GET['servicio'] ?? 0) == (int)$s['id_servicio'] ? 'selected' : '' ?>
                        >
                            <?= e($s['nombre']) ?>
                            - $<?= number_format($s['precio'], 0, ',', '.') ?>
                            - <?= $s['duracion'] ?> minutos
                        </option>

                    <?php endforeach; ?>

                </select>
            </label>

            <label>
                Profesional

                <select name="empleado" required>

                    <option value="">Selecciona un profesional</option>

                    <?php foreach ($empleados as $emp): ?>

                        <option
                            value="<?= $emp['id_empleado'] ?>"
                            <?= (int)($_POST['empleado'] ?? 0) == (int)$emp['id_empleado'] ? 'selected' : '' ?>
                        >
                            <?= e($emp['nombres'] . ' ' . $emp['apellidos'] . ' - ' . $emp['especialidad']) ?>
                        </option>

                    <?php endforeach; ?>

                </select>
            </label>

            <label>
                Fecha

                <input
                    type="date"
                    name="fecha"
                    min="<?= date('Y-m-d') ?>"
                    value="<?= e($_POST['fecha'] ?? '') ?>"
                    required
                >
            </label>

            <label>
                Hora

                <select name="hora" required>

                    <option value="">Selecciona una hora</option>

                    <?php foreach (['08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30'] as $h): ?>

                        <option <?= ($_POST['hora'] ?? '') == $h ? 'selected' : '' ?>>
                            <?= $h ?>
                        </option>

                    <?php endforeach; ?>

                </select>
            </label>

            <label>
                Modalidad de pago

                <select name="modalidad" id="modalidad">
                    <option value="En establecimiento">En establecimiento</option>
                    <option value="En linea">En línea</option>
                </select>
            </label>

            <label class="full">
                Método de pago

                <select name="metodo" required>

                    <option value="">Selecciona un método</option>

                    <?php foreach ($metodos as $m): ?>

                        <option value="<?= $m['id_metodo'] ?>">
                            <?= e($m['nombre']) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

                <small>
                    Los pagos en línea quedan pendientes de confirmación.
                </small>
            </label>

            <label class="full">
                ¿Alguna preferencia? (Opcional)

                <textarea
                    name="observaciones"
                    rows="3"
                    maxlength="1000"
                    placeholder="Cuéntanos si tienes algún diseño o detalle en mente..."
                ><?= e($_POST['observaciones'] ?? '') ?></textarea>
            </label>

            <div class="booking-summary full">

                <span>Resumen de tu reserva</span>

                <strong id="booking-price">
                    Selecciona un servicio
                </strong>

                <small id="booking-duration"></small>

            </div>

            <div class="full">

                <button class="btn btn-block" type="submit">
                    Confirmar solicitud <span>→</span>
                </button>

            </div>

        </form>

    </div>

</section>

<?php require 'includes/footer.php'; ?>
