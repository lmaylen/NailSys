
<?php
require 'config.php';

$titulo = 'Nuestros servicios | NailSys';

$servicios = $pdo->query("
    SELECT s.*, c.nombre AS categoria
    FROM servicios s
    INNER JOIN categorias c ON c.id_categoria = s.id_categoria
    WHERE s.estado = 'Activo'
    ORDER BY s.id_servicio
")->fetchAll();

require 'includes/header.php';
?>

<section class="page-section">
    <div class="container">
        <div class="section-heading">
            <div>
                <span class="eyebrow">DESCUBRE NUESTRO CATÁLOGO</span>
                <h1>Nuestros servicios</h1>
            </div>
            <p>
                Encuentra el tratamiento ideal para ti.
                Consulta los precios y la duración de cada servicio.
            </p>
        </div>

        <?php if (!$servicios): ?>
            <div class="empty-state">
                <h2>No hay servicios disponibles</h2>
                <p>Pronto tendremos nuevas opciones para ti.</p>
            </div>
        <?php else: ?>

            <div class="service-grid">
                <?php foreach ($servicios as $i => $s): ?>
                    <article class="service-card">
                        <div class="service-number">
                            <?= str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT) ?>
                            <span>✦</span>
                        </div>

                        <span class="service-category">
                            <?= e($s['categoria']) ?>
                        </span>

                        <h3><?= e($s['nombre']) ?></h3>

                        <p><?= e($s['descripcion']) ?></p>

                        <div class="service-bottom">
                            <div>
                                <strong>
                                    $<?= number_format((float)$s['precio'], 0, ',', '.') ?>
                                </strong>
                                <small>
                                    <?= (int)$s['duracion'] ?> minutos
                                </small>
                            </div>

                            <a
                                class="round-link"
                                href="<?= usuario_actual()
                                    ? 'reservar.php?servicio=' . (int)$s['id_servicio']
                                    : 'registro.php' ?>"
                                aria-label="Reservar servicio"
                            >↗</a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>

        <?php endif; ?>
    </div>
</section>

<?php require 'includes/footer.php'; ?>
