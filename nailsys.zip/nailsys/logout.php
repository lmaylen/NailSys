
<?php

require 'config.php';

$_SESSION = [];

if (ini_get('session.use_cookies')) {

    $datos = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $datos['path'],
        $datos['domain'],
        $datos['secure'],
        $datos['httponly']
    );

}

session_destroy();

header('Location: index.php');
exit;

?>
