
document.addEventListener('DOMContentLoaded', function () {

    const botonMenu = document.querySelector('.menu-toggle');
    const navegacion = document.querySelector('.main-nav');

    if (botonMenu && navegacion) {

        botonMenu.addEventListener('click', function () {

            const menuAbierto = navegacion.classList.toggle('nav-open');

            botonMenu.setAttribute('aria-expanded', menuAbierto);
            botonMenu.textContent = menuAbierto ? '✕' : '☰';

        });
    }

    const servicio = document.querySelector('#servicio');
    const precio = document.querySelector('#booking-price');
    const duracion = document.querySelector('#booking-duration');

    if (servicio && precio && duracion) {

        function actualizarServicio() {

            const opcion = servicio.options[servicio.selectedIndex];

            if (!opcion || !opcion.value) {
                precio.textContent = 'Selecciona un servicio';
                duracion.textContent = '';
                return;
            }

            const valor = Number(opcion.dataset.price || 0);

            precio.textContent = valor.toLocaleString('es-CO', {
                style: 'currency',
                currency: 'COP',
                maximumFractionDigits: 0
            });

            duracion.textContent = 'Duración aproximada: ' + opcion.dataset.duration + ' minutos';
        }

        servicio.addEventListener('change', actualizarServicio);

        actualizarServicio();
    }

});
