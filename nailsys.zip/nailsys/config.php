
<?php

session_start();

$host = 'localhost';
$baseDatos = 'nailsys';
$usuario = 'root';
$contrasena = '';

try {

    $pdo = new PDO(
        "mysql:host=$host;dbname=$baseDatos;charset=utf8mb4",
        $usuario,
        $contrasena
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

} catch (PDOException $error) {

    http_response_code(500);

    exit('No se pudo conectar con la base de datos. Revisa que MySQL esté iniciado y que exista la base de datos nailsys.');

}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function e(?string $valor): string {

    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');

}

function csrf_field(): string {

    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';

}

function validar_csrf(): void {

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        $token = $_POST['csrf'] ?? '';

        if (!hash_equals($_SESSION['csrf'] ?? '', $token)) {

            http_response_code(419);

            exit('La sesión del formulario venció. Regresa e inténtalo nuevamente.');

        }

    }

}

function usuario_actual(): ?array {

    return $_SESSION['usuario'] ?? null;

}

function exigir_login(): void {

    if (!usuario_actual()) {

        header('Location: login.php');

        exit;

    }

}

function flash(string $tipo, string $mensaje): void {

    $_SESSION['flash'] = [
        'tipo' => $tipo,
        'mensaje' => $mensaje
    ];

}

function obtener_flash(): ?array {

    $mensaje = $_SESSION['flash'] ?? null;

    unset($_SESSION['flash']);

    return $mensaje;

}

?>
