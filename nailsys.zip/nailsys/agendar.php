
<?php
session_start();
require_once 'conexion.php';

// Verificar que el cliente haya iniciado sesión
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit;
}

// Obtener el cliente que inició sesión
$id_usuario = $_SESSION['id_usuario'];

$consultaCliente = $conexion->prepare(
    "SELECT id_cliente FROM clientes WHERE id_usuario = ?"
);
$consultaCliente->bind_param("i", $id_usuario);
$consultaCliente->execute();
$resultadoCliente = $consultaCliente->get_result();
$cliente = $resultadoCliente->fetch_assoc();

if (!$cliente) {
    die("No se encontró el registro del cliente.");
}

$id_cliente = $cliente['id_cliente'];

// Obtener servicios activos
$servicios = $conexion->query(
    "SELECT id_servicio, nombre, precio, duracion
     FROM servicios
     WHERE estado = 'Activo'
     ORDER BY nombre"
);

// Obtener empleados activos
$empleados = $conexion->query(
    "SELECT e.id_empleado, u.nombres, u.apellidos, e.especialidad
     FROM empleados e
     INNER JOIN usuarios u ON e.id_usuario = u.id_usuario
     WHERE e.estado = 'Activo'
       AND u.estado = 'Activo'
     ORDER BY u.nombres"
);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar cita | NailSys</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>

<header class="encabezado">
    <h1>NailSys</h1>
    <nav>
        <a href="index.php">Inicio</a>
        <a href="servicios.php">Servicios</a>
        <a href="cliente.php">Mi panel</a>
    </nav>
</header>

<main class="contenedor-agendar">

    <section class="agendar-intro">
        <h2>Agenda tu cita</h2>
        <p>Elige tu servicio, especialista y horario favorito.</p>
    </section>

    <form action="guardar_cita.php" method="POST" class="formulario-agendar">

        <label for="id_servicio">Selecciona un servicio</label>
        <select name="id_servicio" id="id_servicio" required>
            <option value="">Selecciona un servicio</option>

            <?php while ($servicio = $servicios->fetch_assoc()): ?>
                <option value="<?php echo $servicio['id_servicio']; ?>">
                    <?php echo htmlspecialchars($servicio['nombre']); ?>
                    - $<?php echo number_format($servicio['precio'], 0, ',', '.'); ?>
                </option>
            <?php endwhile; ?>
        </select>

        <label for="id_empleado">Selecciona una especialista</label>
        <select name="id_empleado" id="id_empleado" required>
            <option value="">Selecciona una especialista</option>

            <?php while ($empleado = $empleados->fetch_assoc()): ?>
                <option value="<?php echo $empleado['id_empleado']; ?>">
                    <?php echo htmlspecialchars(
                        $empleado['nombres'] . ' ' .
                        $empleado['apellidos'] . ' - ' .
                        $empleado['especialidad']
                    ); ?>
                </option>
            <?php endwhile; ?>
        </select>

        <label for="fecha">Fecha de la cita</label>
        <input type="date" name="fecha" id="fecha"
               min="<?php echo date('Y-m-d'); ?>" required>

        <label for="hora_inicio">Hora de la cita</label>
        <input type="time" name="hora_inicio" id="hora_inicio" required>

        <label for="observaciones">Observaciones</label>
        <textarea name="observaciones" id="observaciones"
                  placeholder="Cuéntanos si tienes alguna solicitud especial"></textarea>

        <button type="submit">Continuar con mi reserva</button>

    </form>

</main>

</body>
</html>
