
<?php

require 'config.php';

exigir_login();

$usuario = usuario_actual();

if (($usuario['rol'] ?? '') != 'Administrador') {
    http_response_code(403);
    exit('No tienes permisos para acceder a esta sección.');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    validar_csrf();

    $idCita = (int)($_POST['id_cita'] ?? 0);
    $estado = $_POST['estado'] ?? '';

    $estadosPermitidos = [
        'Pendiente',
        'Confirmada',
        'En proceso',
        'Completada',
        'Cancelada',
        'No asistio'
    ];

    if (in_array($estado, $estadosPermitidos, true)) {

        $consulta = $pdo->prepare("
            UPDATE citas
            SET estado = ?
            WHERE id_cita = ?
        ");

        $consulta->execute([
            $estado,
            $idCita
        ]);

        flash('success', 'Estado de la cita actualizado.');
    }

    header('Location: admin.php');
    exit;
}

$consulta = $pdo->query("
    SELECT
        c.id_cita,
        c.fecha,
        c.hora_inicio,
        c.estado,
        CONCAT(uc.nombres, ' ', uc.apellidos) AS cliente,
        CONCAT(ue.nombres, ' ', ue.apellidos) AS empleado,
        GROUP_CONCAT(s.nombre SEPARATOR ', ') AS servicios
    FROM citas c
    INNER JOIN clientes cl ON cl.id_cliente = c.id_cliente
    INNER JOIN usuarios uc ON uc.id_usuario = cl.id_usuario
    INNER JOIN empleados em ON em.id_empleado = c.id_empleado
    INNER JOIN usuarios ue ON ue.id_usuario = em.id_usuario
    LEFT JOIN detalle_citas dc ON dc.id_cita = c.id_cita
    LEFT JOIN servicios s ON s.id_servicio = dc.id_servicio
    GROUP BY c.id_cita
    ORDER BY c.fecha DESC, c.hora_inicio DESC
");

$citas = $consulta->fetchAll();

$consulta = $pdo->query("
    SELECT
        COUNT(*) AS total,
        SUM(estado = 'Pendiente') AS pendientes,
        SUM(estado = 'Confirmada') AS confirmadas
    FROM citas
");

$stats = $consulta->fetch();

$titulo = 'Administración | NailSys';

require 'includes/header.php';

?>

<section class="page-section">
    <div class="container">

        <span class="eyebrow">PANEL DE CONTROL</span>

        <h1>Administración</h1>

        <div class="stats-grid">

            <div class="stat-card">
                <small>Total de citas</small>
                <strong><?= (int)$stats['total'] ?></strong>
            </div>

            <div class="stat-card">
                <small>Pendientes</small>
                <strong><?= (int)$stats['pendientes'] ?></strong>
            </div>

            <div class="stat-card">
                <small>Confirmadas</small>
                <strong><?= (int)$stats['confirmadas'] ?></strong>
            </div>

        </div>

        <div class="table-wrap">

            <table>
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Cliente</th>
                        <th>Servicio</th>
                        <th>Profesional</th>
                        <th>Estado</th>
                        <th>Actualizar</th>
                    </tr>
                </thead>

                <tbody>

                    <?php foreach ($citas as $cita): ?>

                        <tr>
                            <td>
                                <?= date('d/m/Y', strtotime($cita['fecha'])) ?>
                                <br>
                                <?= date('H:i', strtotime($cita['hora_inicio'])) ?>
                            </td>

                            <td><?= e($cita['cliente']) ?></td>

                            <td><?= e($cita['servicios']) ?></td>

                            <td><?= e($cita['empleado']) ?></td>

                            <td><?= e($cita['estado']) ?></td>

                            <td>
                                <form method="post" class="inline-form">

                                    <?= csrf_field() ?>

                                    <input
                                        type="hidden"
                                        name="id_cita"
                                        value="<?= (int)$cita['id_cita'] ?>"
                                    >

                                    <select name="estado">

                                        <?php foreach ($estadosPermitidos as $estado): ?>

                                            <option
                                                value="<?= e($estado) ?>"
                                                <?= $estado == $cita['estado'] ? 'selected' : '' ?>
                                            >
                                                <?= e($estado) ?>
                                            </option>

                                        <?php endforeach; ?>

                                    </select>

                                    <button class="btn btn-small" type="submit">
                                        Guardar
                                    </button>

                                </form>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                </tbody>
            </table>

        </div>

    </div>
</section>

<?php require 'includes/footer.php'; ?>
